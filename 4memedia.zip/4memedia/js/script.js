let mainObj;
(function ($) {
  mainObj = {
    //---------Carousel-----------
    bs_carousel_init: function () {
        $('#carouselExample').carousel({
          interval: 6000
        })
        $('#carouselExample').on('slide.bs.carousel', function (e) {

            var $e = $(e.relatedTarget);
            var idx = $e.index();
            var itemsPerSlide = 4;
            var totalItems = $('.carousel-item').length;
            
            if (idx >= totalItems-(itemsPerSlide-1)) {
                var it = itemsPerSlide - (totalItems - idx);
                for (var i=0; i<it; i++) {
                    // slides sa prihodia za item
                    if (e.direction=="left") {
                        $('.carousel-item').eq(i).appendTo('.carousel-inner');
                    }
                    else {
                        $('.carousel-item').eq(0).appendTo('.carousel-inner');
                    }
                }
            }
        });
    },
    // ---------Navigacia-----------
    navigation_init: function () {
      var $el,
        leftPos,
        newWidth,
        $mainNav = $(".navbar-nav");

      $mainNav.append("<li id='magic-line'></li>");
      var $magicLine = $("#magic-line");

      $magicLine
        .width($(".active").width())
        .css("left", $(".active a").position().left)
        .data("origLeft", $magicLine.position().left)
        .data("origWidth", $magicLine.width());

      $(".navbar-nav li a").hover(
        function() {
          $el = $(this);
          leftPos = $el.position().left;
          newWidth = $el.parent().width();
          $magicLine.stop().animate({
            left: leftPos,
            width: newWidth
          });
        },
        function() {
          $magicLine.stop().animate({
            left: $magicLine.data("origLeft"),
            width: $magicLine.data("origWidth")
          });
        }
      );
    },
    //---------Zoscrollovanie-----------
    zoscrollovanie_init: function () {
      var menu = $(".navbar-nav"),
        menuLinks = menu.find("a");

      menuLinks.on("click", function (e) {
        e.preventDefault();
        $("html,body")
          .stop()
          .animate(
            { scrollTop: $(this.hash).offset().top },
            2000,
            "easeInOutCubic"
          );
      });
    },

    customInit: function () {
      this.bs_carousel_init();
      this.navigation_init();
      this.zoscrollovanie_init();
    },
  };

  jQuery(document).ready(function () {
    mainObj.customInit();

    $(window).resize(function () {});
  });

  //---------Back to top-----------
  var backToTop = $(".back-to-top");
  backToTop
    .hide()
    .appendTo("body")
    .on("click", function () {
      $("html,body").animate({ scrollTop: 0 }, 1600, "easeInOutCubic");
    });

  var win = $(window);
  win.on("scroll", function () {
    if (win.scrollTop() >= 700) backToTop.fadeIn(1000);
    else backToTop.fadeOut(500);
  });

})(jQuery);